package com.faysal.smsautomation.Models

class Posts : ArrayList<PostsItem>()