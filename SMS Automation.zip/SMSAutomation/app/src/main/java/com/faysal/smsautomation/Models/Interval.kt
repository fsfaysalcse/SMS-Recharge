package com.faysal.smsautomation.Models

data class Interval(
    val second: String
)