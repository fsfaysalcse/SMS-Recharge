package com.faysal.smsautomation.Models

data class Notice(
    val Response: String
)