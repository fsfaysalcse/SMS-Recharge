package com.faysal.smsautomation

import android.app.ProgressDialog
import android.text.TextUtils
import android.util.Patterns
import android.view.View
import android.webkit.URLUtil
import com.google.android.material.snackbar.Snackbar


object Util {
    private var loading : ProgressDialog? = null
    fun showAlertMessage(view: View, message: String) {
        Snackbar.make(
            view,
            message,
            Snackbar.LENGTH_LONG
        ).show()
    }

    fun String.isEmailValid(): Boolean {
        return !TextUtils.isEmpty(this) && android.util.Patterns.EMAIL_ADDRESS.matcher(this)
            .matches()
    }

    fun String.isUrlValid(): Boolean {
        return URLUtil.isValidUrl(this) && Patterns.WEB_URL.matcher(this).matches()
    }

    fun ProgressDialog.showDialoge(){
        this.setMessage("Please wait...")
        this.show()
    }
    fun ProgressDialog.dismiss(){
        this.dismiss()
    }
}