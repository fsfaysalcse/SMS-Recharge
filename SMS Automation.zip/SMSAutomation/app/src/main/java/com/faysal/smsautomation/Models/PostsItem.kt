package com.faysal.smsautomation.Models

data class PostsItem(
    val body: String,
    val id: Int,
    val title: String,
    val userId: Int
)