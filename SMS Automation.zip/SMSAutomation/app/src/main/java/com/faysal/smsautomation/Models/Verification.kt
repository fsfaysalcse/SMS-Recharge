package com.faysal.smsautomation.Models

data class Verification(
    val message: String,
    val status: Int
)