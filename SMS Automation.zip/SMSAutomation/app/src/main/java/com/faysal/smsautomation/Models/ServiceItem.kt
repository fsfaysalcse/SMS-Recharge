package com.faysal.smsautomation.Models

data class ServiceItem(
    val service: String
)