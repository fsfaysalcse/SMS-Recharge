package com.faysal.smsautomation.Models

class Service : ArrayList<ServiceItem>()