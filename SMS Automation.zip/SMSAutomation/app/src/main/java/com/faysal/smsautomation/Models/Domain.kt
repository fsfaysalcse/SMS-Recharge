package com.faysal.smsautomation.Models

data class Domain(
    val status: String,
    val message: String,
    val success: Boolean
)